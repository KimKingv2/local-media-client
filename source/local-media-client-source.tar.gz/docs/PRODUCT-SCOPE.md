# Product Scope 0.1

## Product statement

A self-owned, local-first media-centre client inspired by the core experience of 网易爆米花, but with independent data, storage, playback, and provider choices.

## Supported platforms

| Platform | Primary input | Primary experience | Priority |
|---|---|---|---|
| Android TV / Google TV | D-pad remote, media keys | 10-foot poster-first library and playback | P0 |
| Android tablet | Touch, keyboard, mouse | Adaptive landscape/portrait library | P0 |
| Android phone | Touch | Compact library, search, continue watching | P0 |
| macOS | Keyboard, mouse, trackpad | Desktop library, source management, windowed playback | P1 |

## Must-have capabilities

1. Local catalogue: movies, series, seasons, episodes, anime, specials, and collections.
2. Metadata matching: automatic search, confidence scoring, manual correction, provider IDs, and local artwork.
3. WebDAV source management: add, test, browse, index, pause, reconnect, and remove a source without deleting locally matched metadata by accident.
4. Playback: direct remote read where possible, HTTP redirects, byte ranges, seek, resume, audio/subtitle track selection, and playback diagnostics.
5. Library operations: search, filters, sorting, watched/unwatched, favourites, multi-version files, and duplicate detection.
6. Local persistence: SQLite plus local image files; source credentials held in OS secure storage.
7. Portability: export/import the local catalogue and artwork, with schema-versioned backup manifests.

## Explicit non-goals for this client

- No Cloudflare, Workers, D1, hosted API, remote database, account system, or mandatory cloud sync.
- No server-side video transcoding.
- No copying complete video files into the app's private storage as an import requirement.
- Initial remote media protocol: standard WebDAV only. Range and redirect support are detected per server/resource rather than assumed.
- No automatic upload of viewing history, filenames, or metadata to any service.

## Failure behavior

- Metadata provider offline: show the existing local catalogue and cached metadata.
- Media source offline: show the catalogue and mark the affected source/files unavailable; do not delete entries.
- Credentials expired: ask for reauthentication and keep the catalogue intact.
- Player cannot decode a file: report the detected container/codecs/tracks and offer another compatible backend if available; do not silently transcode on a server.
- App upgrade interrupted: preserve the previous database and perform versioned migrations transactionally.

## Product acceptance gates

- TV: all core flows can be completed with only D-pad, Select, and Back.
- Phone/tablet: core flows work without a keyboard or mouse.
- macOS: core flows work with keyboard and pointer, including source browsing.
- Local-first: airplane-mode launch still shows the last indexed catalogue.
- Storage: no full-file hashing during routine scan; progress writes are debounced; caches are independently clearable.
- Security: credentials and signed URLs never appear in SQLite, backups, analytics, or ordinary logs.
