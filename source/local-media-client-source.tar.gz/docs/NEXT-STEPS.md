# Next Steps

## Phase 0 is complete when

- [x] Project boundaries and four target platforms are written down.
- [x] Flutter app shell and adaptive starting layout exist.
- [x] Initial local SQLite catalogue schema exists.
- [x] Source, metadata, and playback contracts are separated.
- [x] Credential references are separated from ordinary catalogue data.
- [x] TV D-pad package is wired into the app shell.
- [ ] Flutter SDK build/analyze/test on the developer Mac.
- [ ] Android and macOS native runner folders generated.
- [ ] Android TV manifest, Leanback launcher category, and banner added.

## Phase 1: standard WebDAV media-source implementation

WebDAV is the only remote media protocol in the initial product scope. Do not add OpenList-specific APIs, SMB, or other provider adapters in this phase.

Implemented in this increment:

1. WebDAV source manager: add, connection-test, save, enable/disable, browse, and remove.
2. Anonymous and Basic authentication; Basic credentials are resolved from OS secure storage. SQLite keeps only an opaque credential reference.
3. `PROPFIND` connection test and `Depth: 1` directory listing.
4. Namespace-independent multistatus XML parsing and source-relative paths.
5. Resource stat using `PROPFIND` with `Depth: 0`.
6. Client-side paging over the direct-child result set (WebDAV itself has no standard paging cursor).
7. Playback URI resolution using `HEAD`, without auto-following redirects.
8. One-byte `Range: bytes=0-0` capability probe; response stream is cancelled immediately after headers.
9. Redirect handling strips Authorization on cross-origin redirects and HTTPS-to-HTTP downgrades.

Remaining validation:

- Run unit tests against MockClient and sqflite_common_ffi, then test against at least two real WebDAV servers.
- Test anonymous and Basic authentication, TLS, Unicode/space paths, large directories, server-specific 207 XML, 401/403/404 handling, and network interruption.
- Verify the actual player can pass the resolved headers and follow the returned URL without logging credentials or signed URLs.
- Add background execution, resumable scans, retry of inaccessible subfolders, and source include/exclude rules after real-server validation.

## Phase 2: player proof of concept

Use exactly the same known test media on an Android TV and macOS. Record the device model, OS version, player backend, codec, audio output mode, subtitle type, HDR state, seek result, and any failure. Choose a backend only after this matrix has been tested.

## Phase 3: filename parsing and scraper

Build filename parsing and sidecar association on top of the local file index, then metadata matching. Keep scanning independent of metadata availability. Add manual matching and a metadata lock before automatic refresh is introduced.

## Phase 4: product UI

Replace placeholder cards with real SQLite-backed library sections. Implement TV focus restoration and remote-only flows before polishing phone/tablet layouts. Then complete macOS sidebar, window, keyboard shortcuts, and source browsing.
