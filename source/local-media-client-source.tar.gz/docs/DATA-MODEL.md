# Local Data Model 0.1

All timestamps are UTC epoch milliseconds. The initial SQL schema is in `lib/core/database/local_database.dart`.

| Table | Purpose | Important rule |
|---|---|---|
| `media_sources` | Source definitions | Secrets are represented only by `credential_ref` |
| `media_items` | Normalized movie/series/season/episode records | Stable app-generated primary key; provider IDs live in JSON |
| `media_files` | Physical file entries | Source-relative path; unique `(source_id, relative_path)`; `media_item_id` stays nullable until a file is matched to a work |
| `people` | Cast/crew | Deduplicated person records |
| `media_people` | Work-to-person roles | Role and character are explicit |
| `genres` | Normalized genres | Unique display name initially |
| `media_item_genres` | Work-to-genre relation | Many-to-many |
| `watch_states` | Resume and completion state | Device-local; updated with debounced writes |
| `scan_jobs` | Scan progress and errors | Completed, failed, or cancelled state with counts; resume is planned, not implemented |
| `metadata_cache` | Provider response cache | Expiry-aware; never stores provider credentials |

## Later schema additions (not yet implemented)

- Collections and user-defined tags.
- Season/episode hierarchy fields and absolute/season episode numbers.
- Multiple versions, editions, parts, cuts, and external subtitle/audio file relations.
- Artwork variants (poster, backdrop, logo, thumb, clearart) plus provenance.
- Manual match lock, match score, provider attribution, and refresh timestamps.
- Playback sessions and per-file stream diagnostics.
- Source scan exclusions, include rules, and file type rules.

## Stability requirements

- Use UUIDs or similarly collision-resistant app-generated IDs, not provider IDs as primary keys.
- The current WebDAV source-removal action deletes its file entries via `ON DELETE CASCADE` but retains normalized work records and local artwork. Additional cleanup choices can be added later.
- Deleting a normalized work sets `media_files.media_item_id` to null; it must not delete the remote file index. Deleting the source removes only its source-owned file rows.
- A schema migration must be transactional and preserve a pre-upgrade backup when practical.
